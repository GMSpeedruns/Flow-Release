/*
Navicat MySQL Data Transfer

Source Server         : Main
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : prestige_dev

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2014-02-16 04:22:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `bhop_mapareas`
-- ----------------------------
DROP TABLE IF EXISTS `bhop_mapareas`;
CREATE TABLE `bhop_mapareas` (
  `nID` int(11) NOT NULL AUTO_INCREMENT,
  `szMap` varchar(255) NOT NULL,
  `nType` tinyint(4) NOT NULL,
  `szData` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`nID`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of bhop_mapareas
-- ----------------------------
INSERT INTO `bhop_mapareas` VALUES ('1', 'bhop_exodus', '4', '-328,11992,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('2', 'bhop_exodus', '4', '-296,12095,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('3', 'bhop_exodus', '4', '-655,12151,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('4', 'bhop_exodus', '4', '-815,11920,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('5', 'bhop_exodus', '4', '-911,11840,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('6', 'bhop_exodus', '4', '-815,11808,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('7', 'bhop_exodus', '4', '-1071,11840,4703;-2,-2,-1.5;2,2,1');
INSERT INTO `bhop_mapareas` VALUES ('8', 'bhop_exodus', '1', '872,157,-295;1373,670,116');
INSERT INTO `bhop_mapareas` VALUES ('9', 'bhop_exodus', '2', '2416,8553,5701;2969,9120,5819;-11027,6770,2496');
INSERT INTO `bhop_mapareas` VALUES ('10', 'bhop_exodus', '2', '1995,8145,5031;3251,9390,5346;3207,8061,5072');
INSERT INTO `bhop_mapareas` VALUES ('11', 'bhop_exodus', '2', '-6369,-4993,4047;-6367,-4991,4049;-6368,-4992,4040');
INSERT INTO `bhop_mapareas` VALUES ('12', 'bhop_guly', '3', '2144.5,-1012,-84;level8');
INSERT INTO `bhop_mapareas` VALUES ('13', 'bhop_guly', '1', '-2541,-792,-157;-2001,-329,179');
INSERT INTO `bhop_mapareas` VALUES ('14', 'kz_bhop_indiana', '8', '-40,549,-2763;222,1154,-2364;16;18');
INSERT INTO `bhop_mapareas` VALUES ('15', 'kz_bhop_indiana', '8', '4131,4037,-4300;4492,4221,-4060;1;18');
INSERT INTO `bhop_mapareas` VALUES ('16', 'kz_bhop_indiana', '2', '4288,3370,-3872;4336,3460,-3680;4314,3814,-3870');
INSERT INTO `bhop_mapareas` VALUES ('17', 'bhop_cw_journey', '2', '15175,6853,640;15311,7023,725;12924,3997,624');
INSERT INTO `bhop_mapareas` VALUES ('18', 'bhop_infog', '4', '-2127.5,5608.5,39.5;-25.5,-6.5,-16.5;25.5,6.5,16.5');
INSERT INTO `bhop_mapareas` VALUES ('19', 'bhop_infog', '4', '2788,-2926,-757.5;-37,-119,-0.5;37,119,0.5');
INSERT INTO `bhop_mapareas` VALUES ('20', 'bhop_ananas', '2', '5948,-3972,576;6098,-3900,787;8429,-5231,1179');
INSERT INTO `bhop_mapareas` VALUES ('21', 'bhop_lost_world', '100', 'custom');
INSERT INTO `bhop_mapareas` VALUES ('22', 'bhop_arcane_v1', '1', '-1004,-965,14400;-716,920,14725');
INSERT INTO `bhop_mapareas` VALUES ('23', 'bhop_exquisite', '101', 'custom');
INSERT INTO `bhop_mapareas` VALUES ('24', 'bhop_areaportal_v1', '3', '-1032,-2696.5,-455;level_redcorridor7');
INSERT INTO `bhop_mapareas` VALUES ('25', 'bhop_areaportal_v1', '3', '-6947,-3655.5,-455;level_greencorridor3');
INSERT INTO `bhop_mapareas` VALUES ('26', 'bhop_catalyst', '9', '-8438,-58,5353');
INSERT INTO `bhop_mapareas` VALUES ('27', 'bhop_cartoons', '4', '2947,12856,167;3032,13862,297');
INSERT INTO `bhop_mapareas` VALUES ('28', 'bhop_cartoons', '4', '7315,4713,-2545;7375,5116,-2439');
INSERT INTO `bhop_mapareas` VALUES ('29', 'bhop_cartoons', '4', '6666,4705,-2552;6730,5179,-2452');
INSERT INTO `bhop_mapareas` VALUES ('30', 'bhop_badges_ausbhop', '4', '8000,-171,152;8314,492,214');
INSERT INTO `bhop_mapareas` VALUES ('31', 'bhop_badges_ausbhop', '4', '1958,-3649,152;2514,-2004,252');
INSERT INTO `bhop_mapareas` VALUES ('32', 'bhop_badges_ausbhop', '4', '-4794,-6579,152;-4151,-5531,267');
INSERT INTO `bhop_mapareas` VALUES ('33', 'bhop_miku_v2', '4', '-2900,874,-444;-2791,1006,-109');
INSERT INTO `bhop_mapareas` VALUES ('34', 'bhop_miku_v2', '4', '-2895,28,-444;-2799,123,-116');
INSERT INTO `bhop_mapareas` VALUES ('35', 'bhop_choice', '4', '11,-840,128;471,-685,668');
INSERT INTO `bhop_mapareas` VALUES ('36', 'bhop_sqee', '4', '2280,3776,-7751;0,0,0;446,446,5');
INSERT INTO `bhop_mapareas` VALUES ('37', 'bhop_eman_on', '2', '-4772,-12546,-3265;-4611,-12392,-3039;-5309,-11812,-1696');
INSERT INTO `bhop_mapareas` VALUES ('38', 'bhop_strafe_fix', '2', '-3700,-5050,382;-3655,-4968,574;-4044,-4290,734');
INSERT INTO `bhop_mapareas` VALUES ('39', 'bhop_strafe_fix', '2', '-50,-2358,655;14,-2296,847;-626,-2393,2014');
INSERT INTO `bhop_mapareas` VALUES ('40', 'bhop_strafe_fix', '2', '-1050,3030,4350;-963,3510,4542;-209,3259,4446');
INSERT INTO `bhop_mapareas` VALUES ('41', 'bhop_strafe_fix', '7', '16');
INSERT INTO `bhop_mapareas` VALUES ('42', 'kz_bhop_yonkoma', '7', '16');
INSERT INTO `bhop_mapareas` VALUES ('43', 'bhop_angkor', '9', '-1835,-94,2048');
INSERT INTO `bhop_mapareas` VALUES ('44', 'bhop_it_nine-up', '9', '-411,5490,-2126');
INSERT INTO `bhop_mapareas` VALUES ('45', 'bhop_depot', '9', '-15747,-11613,16');
INSERT INTO `bhop_mapareas` VALUES ('46', 'bhop_guly', '2', '504,-1136,-144;387,-1456,-100;-1614,-1290,-144');
