<?php
	include("func.php");
	if (!isset($_GET["s"]) || !isset($_GET["m"]))
	{
		die("This page can only be visited from within Steam Browser!");
	}
	
	$comid = $_GET["s"];
	$mapname = $_GET["m"];
	
	$baseid = "76561197960265728";
	$difference = bcsub($comid, $baseid);
	$oddeven = $difference & 1;
	$authid = ($difference - $oddeven) / 2;
	$steamid = "STEAM_0:$oddeven:$authid";
	
	$apikey = "";
	$steamapi = file_get_contents('http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=' . $apikey. '&steamids=' . $comid . '&format=json');
	$data = json_decode($steamapi, true);
	$username = $data["response"]["players"][0]["personaname"];
	
	$source = source_query('74.91.125.231', '27015');
	$players = $source["status"] == 1 ? $source["players"] . " (" . $source["bots"] . ") / " . $source["playersmax"] : "None";
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>GFL - Bunny Hop</title>
	
	<link rel="shortcut icon" href="favicon.ico">
	<link href='//fonts.googleapis.com/css?family=Open+Sans:300,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="gfl.css">
	
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script type="text/javascript" src="script.js"></script>
</head>
<body>
	<center>
		<img class="logo" src="logo.png"><br />
		<h2 class="map">
			You're joining: Bunny Hop
		</h2>
		<table class="userdata">
			<tr>
				<td><img class="icon" src="icon_steam.png" /></td>
				<td><b>SteamID:</b> <?php echo $steamid; ?></td>
			</tr>
			<tr>
				<td><img class="icon" src="icon_user.png" /></td>
				<td><b>User:</b> <?php echo $username; ?></td>
			</tr>
			<tr>
				<td><img class="icon" src="icon_map.png" /></td>
				<td><b>Map:</b> <?php echo $mapname; ?></td>
			</tr>
			<tr>
				<td><img class="icon" src="icon_youtube.png" /></td>
				<td>
					<b>Server:</b> GFL Bunny Hop<br />
					<b>Players:</b> <?php echo $players; ?>
				</td>
			</tr>
		</table>
		<div class="data">
			<span class="status"></span><br />
			<span class="downloading"></span><br />
			<span class="progress"></span>
		</div>
	</center>
	<p class="credits1">Design by ny</p>
	<p class="credits2">Code by Gravious</p>
</body>
</html>