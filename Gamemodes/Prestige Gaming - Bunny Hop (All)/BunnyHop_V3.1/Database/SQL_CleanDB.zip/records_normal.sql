/*
Navicat MySQL Data Transfer

Source Server         : Main
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : prestige_dev

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2014-02-16 04:22:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `records_normal`
-- ----------------------------
DROP TABLE IF EXISTS `records_normal`;
CREATE TABLE `records_normal` (
  `szMap` varchar(255) NOT NULL,
  `szName` varchar(255) DEFAULT NULL,
  `nID` bigint(20) unsigned NOT NULL,
  `nTime` double unsigned NOT NULL,
  `nWeight` double unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of records_normal
-- ----------------------------
