/*
Navicat MySQL Data Transfer

Source Server         : Main
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : prestige_dev

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2014-02-16 04:22:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `bhop_botdata`
-- ----------------------------
DROP TABLE IF EXISTS `bhop_botdata`;
CREATE TABLE `bhop_botdata` (
  `nID` int(11) NOT NULL AUTO_INCREMENT,
  `szMap` varchar(255) NOT NULL,
  `szPlayer` varchar(255) DEFAULT 'Bot',
  `nTime` double NOT NULL,
  `nStyle` tinyint(4) NOT NULL DEFAULT '1',
  `szDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`nID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of bhop_botdata
-- ----------------------------
