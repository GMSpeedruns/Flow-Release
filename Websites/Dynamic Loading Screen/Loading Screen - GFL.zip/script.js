nTotal = 0;

function SetStatusChanged( status )
{
	$('.status').html( "Status: " + status );
}

function DownloadingFile( fileName )
{
	$('.downloading').html( "Downloading: " + fileName );
}

function SetFilesTotal( total )
{
	nTotal = total;
}

function SetFilesNeeded( needed )
{
	if (nTotal == 0) { return; }
	percent = needed / nTotal;
	percent = 1 - percent;
	percent = percent * 100;
	
	$('.progress').html( "Progress: " + Math.round(percent)  + "%" );
}

//function GameDetails( servername, serverurl, mapname, maxplayers, steamid, gamemode ) {}