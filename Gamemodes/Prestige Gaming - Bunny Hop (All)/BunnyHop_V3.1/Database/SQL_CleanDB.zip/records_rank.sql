/*
Navicat MySQL Data Transfer

Source Server         : Main
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : prestige_dev

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2014-02-16 04:22:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `records_rank`
-- ----------------------------
DROP TABLE IF EXISTS `records_rank`;
CREATE TABLE `records_rank` (
  `nID` bigint(20) unsigned NOT NULL,
  `nTotalWeight` double unsigned DEFAULT NULL,
  PRIMARY KEY (`nID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of records_rank
-- ----------------------------
