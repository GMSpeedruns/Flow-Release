﻿using NAudio.Wave;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;

namespace SurflineTicketManager
{
    class Program
    {
        private const string __CONFIG = "config.ini";
        private const string __LOG = "output.log";

        private static string __PATH = "";
        private static string __GSPATH = "";
        private static string __JAVA = "";
        private static string __PREFIX = "";

        private static string __WEB_REPORT = "";
        private static string __WEB_REPORT_FAIL = "";

        private static bool __CONTROL = false;

        private static Dictionary<int, String> handling;

        static void Main(string[] args)
        {
            if (!File.Exists(__CONFIG))
            {
                Console.WriteLine("Couldn't find the config.ini file. Make sure it's in the same folder as this program is.");
                Console.ReadLine();
                return;
            }
            else
            {
                string data = File.ReadAllText(__CONFIG);
                string[] lines = Regex.Split(data, "\n");

                foreach (string line in lines)
                {
                    if (line.Length > 1 && line.Substring(0, 2) == "//")
                        continue;

                    if (line == "" || line.Length < 4)
                        continue;

                    string readLine = line.Replace("\r", "");

                    string[] items = Regex.Split(readLine, " = ");
                    if (items.Length == 2)
                    {
                        if (items[0] == "LOCAL_PATH")
                            __PATH = items[1];
                        else if (items[0] == "GROOVE_PATH")
                            __GSPATH = items[1];
                        else if (items[0] == "JAVA_PATH")
                            __JAVA = items[1];
                        else if (items[0] == "TICKET_PREFIX")
                            __PREFIX = items[1];
                        else if (items[0] == "REPORT_URL")
                            __WEB_REPORT = items[1];
                        else if (items[0] == "REPORT_URL_FAIL")
                            __WEB_REPORT_FAIL = items[1];
                        else if (items[0] == "SERVER_CONTROL")
                            __CONTROL = items[1] == "Yes" ? true : false;
                        else if (items[0] == "SERVER_DIRECTORY")
                            __PATH_ROOT = items[1];
                        else if (items[0] == "SERVER_SRCDSBOOT")
                            __PATH_SRCDS = items[1];
                        else if (items[0] == "SERVER_DUMPS")
                            __PATH_DUMP = items[1];
                        else
                        {
                            Console.WriteLine("Invalid sub-instruction: " + items[0]);
                            Console.ReadLine();
                            return;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Your config file contained invalid formatting. Please check the README file for instructions.");
                        Console.ReadLine();
                        return;
                    }
                }
            }

            if (!File.Exists(__LOG))
                File.Create(__LOG).Close();

            if (!Directory.Exists(__PATH) || !File.Exists(__GSPATH) || !File.Exists(__JAVA))
            {
                Console.WriteLine("One of these paths was incorrectly set (non-existant): LOCAL_PATH, GROOVE_PATH or JAVA_PATH");
                Console.ReadLine();
                return;
            }
            else if (__CONTROL)
            {
                if (!Directory.Exists(__PATH_ROOT) || !Directory.Exists(__PATH_DUMP) || !File.Exists(__PATH_SRCDS))
                {
                    Console.WriteLine("One of these paths was incorrectly set (non-existant): SERVER_DIRECTORY, SERVER_SRCDSBOOT or SERVER_DUMPS");
                    Console.ReadLine();
                    return;
                }
            }

            AddLog("Program started! Type exit to close!");

            Timer t = new Timer(new TimerCallback(TimerCall), null, 1000, 500);
            handling = new Dictionary<int, String>();

            string szLine;
            while ((szLine = Console.ReadLine()) != "exit")
            {
            }

            AddLog("Program closed manually!");
        }

        static void AddLog(string szText)
        {
            File.AppendAllText(__LOG, "[" + DateTime.Now.ToString("G") + "] " + szText + "\n");
            Console.WriteLine(szText);
        }

        static void TimerCall(object obj)
        {
            if (__CONTROL)
                CheckServerStatus();

            if (handling.Count > 0)
                return;

            string[] files = Directory.GetFiles(__PATH, __PREFIX + "*.txt");
            foreach (string file in files)
            {
                int ticketId = int.Parse(Path.GetFileNameWithoutExtension(file).Replace(__PREFIX, ""));
                if (!handling.ContainsKey(ticketId))
                {
                    string content = File.ReadAllText(file);
                    string[] split = Regex.Split(content, ";");

                    string serviceType = split[0];
                    string serviceId = split[1];

                    AddItem(ticketId, int.Parse(serviceType), serviceId, split);
                }
            }
        }

        static void AddItem(int ticketId, int serviceType, string serviceId, string[] split)
        {
            handling.Add(ticketId, serviceId);
            AddLog("Now handling item with ticket ID: " + ticketId + " (Service: " + serviceType + ")");

            if (serviceType == 1)
            {
                Process p = new Process();
                p.StartInfo = new ProcessStartInfo("youtube-dl.exe", serviceId + " -o \"data/t" + serviceType + "_" + serviceId + ".tmp\" --write-info-json --extract-audio --audio-format mp3");
                p.Start();
                p.WaitForExit(300000);
                int exitCode = -1;
                try
                {
                    exitCode = p.ExitCode;
                }
                catch (Exception e)
                {
                    AddLog("Couldn't retrieve error code after 5 minutes: " + e.Message);
                }

                if (exitCode == 0)
                    ReportItem(ticketId, serviceType, serviceId, split);
                else
                {
                    foreach (var process in Process.GetProcessesByName("ffmpeg"))
                        process.Kill();

                    foreach (var process in Process.GetProcessesByName("youtube-dl"))
                        process.Kill();

                    ReportFail(ticketId, serviceType, serviceId);
                }
            }
            else if (serviceType == 2)
            {
                if (File.Exists(__PATH + __PREFIX + ticketId + ".txt"))
                    File.Delete(__PATH + __PREFIX + ticketId + ".txt");

                handling.Remove(ticketId);
            }
            else if (serviceType == 3)
            {
                Process p = new Process();
                p.StartInfo = new ProcessStartInfo(__JAVA, "-jar \"" + __GSPATH + "\" " + serviceId);
                p.Start();
                p.WaitForExit(300000);
                int exitCode = -1;
                try
                {
                    exitCode = p.ExitCode;
                }
                catch (Exception e)
                {
                    AddLog("Couldn't retrieve error code after 5 minutes: " + e.Message);
                }

                if (exitCode == 0)
                    ReportItem(ticketId, serviceType, serviceId, split);
                else
                {
                    foreach (var process in Process.GetProcessesByName("javaw"))
                        process.Kill();

                    foreach (var process in Process.GetProcessesByName("java"))
                        process.Kill();

                    ReportFail(ticketId, serviceType, serviceId);
                }
            }
        }

        static void ReportItem(int ticketId, int serviceType, string serviceId, string[] split)
        {
            if (File.Exists(__PATH + __PREFIX + ticketId + ".txt"))
                File.Delete(__PATH + __PREFIX + ticketId + ".txt");

            handling.Remove(ticketId);

            string url = __WEB_REPORT + serviceType + ";" + ticketId + ";" + serviceId;
            if (serviceType == 1)
            {
                if (File.Exists(__PATH + "data\\t" + serviceType + "_" + serviceId + ".info.json"))
                {
                    string info = __PATH + "data\\t" + serviceType + "_" + serviceId + ".info.json";
                    string data = File.ReadAllText(info);

                    var a = new { title = "", duration = "" };
                    var c = new JsonSerializer();
                    dynamic jsonObject = c.Deserialize(new StringReader(data), a.GetType());
                    string title = jsonObject.title;
                    string duration = jsonObject.duration;

                    string webtitle = HttpUtility.UrlEncode(title);
                    url = url + ";" + duration + ";" + webtitle;

                    File.Delete(__PATH + "data\\t" + serviceType + "_" + serviceId + ".info.json");
                }
                else
                {
                    url = url + ";0;YouTubeVideo";
                }
            }
            else if (serviceType == 2)
            {

            }
            else if (serviceType == 3)
            {
                if (File.Exists(__PATH + serviceId + ".mp3"))
                    File.Move(__PATH + serviceId + ".mp3", __PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3");
                else
                {
                    Console.WriteLine("Didn't exist? What?...");
                    ReportFail(ticketId, serviceType, serviceId);
                    return;
                }

                int duration = 0;
                string title = "GroovesharkSong";
                string artist = "";

                if (split.Length > 2)
                    title = split[2];

                if (split.Length > 3)
                    artist = split[3];

                if (File.Exists(__PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3"))
                {
                    try
                    {
                        Mp3FileReader reader = new Mp3FileReader(__PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3");
                        TimeSpan length = reader.TotalTime;
                        duration = (int)Math.Ceiling(length.TotalSeconds);

                        // To-Do: Possibly use MediaFoundationReader if still doesn't work
                        // Fixed by installing Windows Desktop Experience on the VPS

                        reader.Close();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }

                url = url + ";" + duration + ";" + title;
                if (artist != "")
                    url = url + ";" + artist;
            }

            var request = WebRequest.Create(url);
            var response = request.GetResponse();
            Stream resStream = response.GetResponseStream();
            StreamReader objReader = new StreamReader(resStream);
            string szText = objReader.ReadToEnd();

            objReader.Close();
            resStream.Close();

            Cleanup(serviceType, serviceId, false);

            AddLog("Successfully completed item with ticket ID: " + ticketId + "! (Service: " + serviceType + " - UID: " + serviceId + ") - Result: " + szText);
        }

        static void ReportFail(int ticketId, int serviceType, string serviceId)
        {
            if (File.Exists(__PATH + __PREFIX + ticketId + ".txt"))
                File.Delete(__PATH + __PREFIX + ticketId + ".txt");

            Cleanup(serviceType, serviceId, true);

            handling.Remove(ticketId);

            string url = __WEB_REPORT_FAIL + ticketId;
            var request = WebRequest.Create(url);
            var response = request.GetResponse();
            Stream resStream = response.GetResponseStream();
            StreamReader objReader = new StreamReader(resStream);
            string szText = objReader.ReadToEnd();

            objReader.Close();
            resStream.Close();

            if (File.Exists(__PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3"))
                File.Delete(__PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3");

            AddLog("Reported item " + serviceId + " with ticket " + ticketId + " on service " + serviceType + " to have failed: " + szText);
        }

        static void Cleanup(int serviceType, string serviceId, bool bMP3)
        {
            if (File.Exists(__PATH + "data\\t" + serviceType + "_" + serviceId + ".info.json"))
                File.Delete(__PATH + "data\\t" + serviceType + "_" + serviceId + ".info.json");

            if (File.Exists(__PATH + "data\\t" + serviceType + "_" + serviceId + ".tmp"))
                File.Delete(__PATH + "data\\t" + serviceType + "_" + serviceId + ".tmp");

            if (bMP3)
            {
                if (File.Exists(__PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3"))
                    File.Delete(__PATH + "data\\t" + serviceType + "_" + serviceId + ".mp3");
            }
        }

        private static bool SetMoving = false;
        private static string TargetMove = "";

        private static string __PATH_ROOT = "";
        private static string __PATH_SRCDS = "";
        private static string __PATH_DUMP = "";
        private static DateTime LastStart;

        static void CheckServerStatus()
        {
            bool DoStart = false;

            var inst = Process.GetProcessesByName("srcds");
            if (inst.Length > 0)
            {
                if (SetMoving && TargetMove != "")
                {
                    File.Copy(TargetMove, __PATH_DUMP + Path.GetFileName(TargetMove));
                    File.Delete(TargetMove);

                    AddLog("Dump found so restarting!");

                    DoStart = true;
                    SetMoving = false;
                    TargetMove = "";
                }
                else
                {
                    string[] files = Directory.GetFiles(__PATH_ROOT, "srcds_*.mdmp");
                    if (files.Length > 0)
                    {
                        SetMoving = true;
                        TargetMove = files[0];
                    }
                }
            }
            else
            {
                Console.WriteLine("No instances found of server!");
                DoStart = true;
            }

            if (DoStart)
            {
                if (LastStart != null)
                {
                    if (DateTime.Now.Subtract(LastStart).TotalSeconds < 5)
                        return;

                    LastStart = DateTime.Now;
                }
                else
                    LastStart = DateTime.Now;

                AddLog("Starting new instance of server");

                Process p = new Process();
                p.StartInfo = new ProcessStartInfo(__PATH_SRCDS);
                p.Start();
            }
        }
    }
}
