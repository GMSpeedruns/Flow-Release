-----------
-- RADIO --
-----------

Radio = {}
Radio.URLRoot = "http://fastdl.prestige-gaming.org/gmod-division/orangebox/garrysmod/sound/wr/"
Radio.URLData = "get.php?video_id="
Radio.URLStream = "sig.php?video_id="
Radio.URLPlayback = "custom/yt_"

Radio.Cache = {}
Radio.ListPerPage = 25

Radio.Queue = {}
Radio.Get = {}

function Radio:LoadCache()
	self.Cache = {}
	SQLQuery("SELECT nID, szTitle, szStream, nRequests, szData FROM bhop_radio ORDER BY nID DESC", function(data)
		if not data or not data[1] then return end
		for k,v in pairs(data) do
			table.insert(Radio.Cache, {tonumber(v["nID"]), v["szTitle"], v["szStream"], tonumber(v["nRequests"]), v["szData"]})
		end
	end)
end

function Radio:GetCachePage(p)
	local Count = #self.Cache
	if p * self.ListPerPage - self.ListPerPage >= Count then return nil end
	local Send, Start = {}, (p - 1) * self.ListPerPage + 1
	for i = Start, Start + self.ListPerPage - 1 do
		if not self.Cache[i] then break end
		table.insert(Send, self.Cache[i])
	end
	return Send
end

function Radio:FindInCache(s)
	local find = {} s = string.lower(s) local added = 0
	for k,v in pairs(Radio.Cache) do
		if added > 25 then break end
		if string.find(string.lower(v[2]), s, 1, true) then
			table.insert(find, v)
			added = added + 1
		end
	end
	return find
end

function Radio:AddSong(ply, id, title)
	if not title then
		SQLQuery("SELECT szTitle, szStream FROM bhop_radio WHERE szData = '" .. id .. "'", function(data)
			if not data or not data[1] then SendMessage(ply, MSG_ID["BhopMsg"], {"An unexpected error occurred!"}) return end
			Radio:Play(ply, data[1]["szStream"], data[1]["szTitle"])
		end)
	else
		local url = Radio.URLRoot .. Radio.URLPlayback .. id .. ".mp3"
		SQLQuery("SELECT szTitle, szStream FROM bhop_radio WHERE szData = '" .. id .. "'", function(data)
			if data and data[1] and data[1]["szStream"] then
				Radio:Play(ply, data[1]["szStream"], data[1]["szTitle"])
			else
				SQLQuery("INSERT INTO bhop_radio VALUES (0, '" .. mSQL:escape(title) .. "', '" .. url .. "', 0, '" .. id .. "')", function()
					Radio:Play(ply, url, title)
					
					SQLQuery("SELECT nID, szTitle, szStream, nRequests, szData FROM bhop_radio WHERE szData = '" .. id .. "'", function(data)
						if not data or not data[1] or not data[1]["nID"] then return end
						local v = data[1]
						table.insert(Radio.Cache, {tonumber(v["nID"]), v["szTitle"], v["szStream"], tonumber(v["nRequests"]), v["szData"]})
					end)
				end)
			end
		end)
	end
end

function Radio:Play(ply, url, title)
	SendData(ply, DATA_ID["Radio"], {1, url, title})
end

function Radio:WR()
	SendGlobalData(DATA_ID["Radio"], {2, Radio.URLRoot .. math.random(1, 8) .. ".wav"})
end

---------

function Radio.Queue:GetTune(ply)
	if not ply.RadioTuned then return end
	if #ply.Radio > 0 then
		local Target = math.random(1, #ply.Radio)
		SendData(ply, DATA_ID["Radio"], {3, ply.Radio[Target]})
		table.remove(ply.Radio, Target)
	else
		ply.RadioTuned = false
		SendData(ply, DATA_ID["Radio"], {3, false})
	end
end

function Radio.Queue:Add(item, ply)
	local inside = false
	for k,v in pairs(ply.Radio) do
		if v[1] == item[1] then
			inside = true
		end
	end
	if not inside then
		table.insert(ply.Radio, item)
		SendMessage(ply, MSG_ID["RadioMsg"], {item[2] .. " has been added to your queue! Total: #" .. #ply.Radio})
	else
		SendMessage(ply, MSG_ID["RadioMsg"], {item[2] .. " is already in your queue!"})
	end
end

function Radio.Queue:CanAdd(id, ply)
	if not ply.Radio or #ply.Radio == 0 then ply.Radio = {} return true end
	for k,v in pairs(ply.Radio) do
		if v[1] == id then
			return false
		end
	end
	return true
end

------------

function Radio.Get:YouTube(ply, url)
	local turl, tag, tlen, len, vid = Radio.URLRoot .. Radio.URLData, "?v=", string.len("?v="), 11, ""
	if string.sub(url, 1, 16) == "http://youtu.be/" then
		turl = turl .. string.sub(string.sub(url, 17), 1, len)
	elseif string.find(url, tag, 1, true) then
		local pos = string.find(url, tag, 1, true)
		vid = string.sub(url, pos + tlen, pos + tlen + len)
		turl = turl .. vid
	end
	
	if turl == Radio.URLRoot .. Radio.URLData then return false end
	SendMessage(ply, MSG_ID["RadioMsg"], {"Please wait while your song is being downloaded!"})
	
	http.Fetch(turl, 
		function(body, length, headers, code)
			if body and body != "" then
				local code = string.sub(body, 1, 3)
				if code == "S00" then
					Radio:AddSong(ply, vid, string.sub(body, 1, 6) == "S000: " and string.sub(body, 7) or nil)
				else
					SendMessage(ply, MSG_ID["RadioMsg"], {"Received invalid YouTube response! (Either blocked in USA or too long)"})
				end
			else
				SendMessage(ply, MSG_ID["RadioMsg"], {"Could not obtain music data from YouTube Video."})
			end
		end,
		function(err)
			SendMessage(ply, MSG_ID["RadioMsg"], {"Could not obtain music data from YouTube Video."})
		end
	)
	
	return true
end

function Radio.Get:YouTubeDirect(ply, url)
	local turl, tag, tlen, len = Radio.URLRoot .. Radio.URLStream, "?v=", string.len("?v="), 11
	if string.sub(url, 1, 16) == "http://youtu.be/" then
		turl = turl .. string.sub(string.sub(url, 17), 1, len)
	elseif string.find(url, tag, 1, true) then
		local pos = string.find(url, tag, 1, true)
		turl = turl .. string.sub(url, pos + tlen, pos + tlen + len)
	end

	if turl == Radio.URLRoot .. Radio.URLStream then return false end
	
	http.Fetch(turl, 
		function(body, length, headers, code)
			if body and body != "" then
				local code = string.sub(body, 1, 6)
				if code == "S000: " then
					local target = string.sub(body, 7)
					Radio:Play(ply, target)
				else
					SendMessage(ply, MSG_ID["RadioMsg"], {"Received invalid YouTube response! (Possibly blocked in USA)"})
				end
			else
				SendMessage(ply, MSG_ID["RadioMsg"], {"Could not obtain music data from YouTube Video."})
			end
		end,
		function(err)
			SendMessage(ply, MSG_ID["RadioMsg"], {"Could not obtain music data from YouTube Video."})
		end
	)
	
	return true
end

-----------

function Radio.Execute(ply, cmd, args)
	if not args[1] or not tonumber(args[1]) then return end
	
	local ID = tonumber(args[1])
	if ID == 0 then
		if not args[2] then return end
		local Direction = tonumber(args[2]) or 0
		if Direction == 0 then
			local page = Radio:GetCachePage(1)
			SendData(ply, DATA_ID["Radio"], {0, page, 1})
		elseif Direction == 1 then
			local Page = ((args[3] and tonumber(args[3])) and tonumber(args[3]) or 1) + 1
			local Cache = Radio:GetCachePage(Page)
			if Cache then SendData(ply, DATA_ID["Radio"], {0, Cache, Page}) end
		elseif Direction == -1 then
			local Page = ((args[3] and tonumber(args[3])) and tonumber(args[3]) or 1) - 1
			if Page < 1 then Page = 1 end
			local Cache = Radio:GetCachePage(Page)
			if Cache then SendData(ply, DATA_ID["Radio"], {0, Cache, Page}) end
		end
	elseif ID == 1 then
		if not args[2] or args[2] == "Search Query" then return end
		if args[2] == "" then Radio.Execute(ply, cmd, {0, 0}) return end
		if args[2] == "queue" then SendData(ply, DATA_ID["Radio"], {0, ply.Radio, 1}) end
		local find = Radio:FindInCache(args[2])
		SendData(ply, DATA_ID["Radio"], {0, find, 1})
	elseif ID == 2 then -- Tune In
		if ply.Radio then
			if ply.RadioTuned then
				SendMessage(ply, MSG_ID["RadioMsg"], {"You are already tuned-in to your queue!"}) return
			end
			ply.RadioTuned = true
			SendMessage(ply, MSG_ID["RadioMsg"], {"You have been tuned-in to your queue!"})
			Radio.Queue:GetTune(ply)
		else
			SendMessage(ply, MSG_ID["RadioMsg"], {"Please add songs to your queue first."})
		end
	elseif ID == 3 then -- Tune Out
		if ply.RadioTuned then
			ply.RadioTuned = false
			SendMessage(ply, MSG_ID["RadioMsg"], {"You have been tuned-out of your queue!"})
			SendData(ply, DATA_ID["Radio"], {3, false})
		else
			SendMessage(ply, MSG_ID["RadioMsg"], {"You are not tuned-in to your queue."})
		end
	elseif ID == 4 then -- Add to Queue
		if not args[2] then return end
		local target = nil
		for k,v in pairs(Radio.Cache) do
			if tonumber(v[1]) == tonumber(args[2]) then
				target = v
				break
			end
		end
		if target then
			if Radio.Queue:CanAdd(target, ply) then
				Radio.Queue:Add(target, ply)
			else
				SendMessage(ply, MSG_ID["RadioMsg"], {"This song is already in the queue!"})
			end
		else
			SendMessage(ply, MSG_ID["RadioMsg"], {"Invalid song requested!"})
		end
	elseif ID == 5 then -- Add Song
		if not args[2] or not args[3] then return end
		local HostID, HostURL = tonumber(args[2]), args[3]
		if HostID == 1 and HostURL != "" and string.find(HostURL, "youtu", 1, true) then
			if not Radio.Get:YouTube(ply, HostURL) then
				SendMessage(ply, MSG_ID["RadioMsg"], {"Invalid YouTube URL Submitted. Please use the standard format."})
			end
		else
			SendMessage(ply, MSG_ID["RadioMsg"], {"Invalid YouTube URL Submitted. Please use the standard format."})
		end
	elseif ID == 6 then
		if not args[2] or not args[3] then return end
		local HostID, HostURL = tonumber(args[2]), args[3]
		if HostID == 1 and HostURL != "" and string.find(HostURL, "youtu", 1, true) then
			Radio.Get:YouTubeDirect(ply, HostURL)
		else
			SendMessage(ply, MSG_ID["RadioMsg"], {"Invalid YouTube URL Submitted. Please use the standard format."})
		end
	elseif ID == 7 then
		Radio.Queue:GetTune(ply)
	elseif ID == 8 then
		if ply.Radio then
			ply.Radio = nil
			ply.RadioTuned = false
			SendMessage(ply, MSG_ID["RadioMsg"], {"Your queue has been cleared and you have been automatically tuned out!"})
		else
			SendMessage(ply, MSG_ID["RadioMsg"], {"Your queue is already empty!"})
		end
	elseif ID == 9 then
		if not ply.Radio or #ply.Radio == 0 then
			SendMessage(ply, MSG_ID["RadioMsg"], {"There are no items in your queue!"})
		else
			SendData(ply, DATA_ID["Radio"], {0, ply.Radio, 1})
		end
	end
end
concommand.Add("bhop_radio", Radio.Execute)