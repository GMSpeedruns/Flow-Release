/*
Navicat MySQL Data Transfer

Source Server         : Main
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : prestige_dev

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2014-02-16 04:23:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `records_special`
-- ----------------------------
DROP TABLE IF EXISTS `records_special`;
CREATE TABLE `records_special` (
  `szMap` varchar(255) NOT NULL,
  `szName` varchar(255) DEFAULT NULL,
  `nID` bigint(20) unsigned NOT NULL,
  `nTime` double unsigned NOT NULL,
  `nStyle` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of records_special
-- ----------------------------
